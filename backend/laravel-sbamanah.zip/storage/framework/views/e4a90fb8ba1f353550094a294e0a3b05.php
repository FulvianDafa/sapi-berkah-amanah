 

<?php $__env->startSection('content'); ?>
<div class="container mx-auto">
    <h1 class="text-2xl font-bold mb-4">Daftar Reseller</h1>
    <div class="overflow-x-auto bg-white rounded shadow">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-slate-800 text-white">
                <tr>
                    <th class="px-4 py-2">Timestamp</th>
                    <th class="px-4 py-2">Nama Lengkap</th>
                    <th class="px-4 py-2">Nomor WhatsApp</th>
                    <th class="px-4 py-2">Profesi</th>
                    <th class="px-4 py-2">Alamat</th>
                    <th class="px-4 py-2">Punya Rekening</th>
                    <th class="px-4 py-2">Nama Bank</th>
                    <th class="px-4 py-2">Nomor Rekening</th>
                    <th class="px-4 py-2">Atas Nama</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $resellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reseller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="px-4 py-2"><?php echo e($reseller['Timestamp'] ?? '-'); ?></td>
                    <td class="px-4 py-2"><?php echo e($reseller['Nama Lengkap'] ?? '-'); ?></td>
                    <td class="px-4 py-2"><?php echo e($reseller['Nomor WhatsApp'] ?? '-'); ?></td>
                    <td class="px-4 py-2"><?php echo e($reseller['Profesi'] ?? '-'); ?></td>
                    <td class="px-4 py-2"><?php echo e($reseller['Alamat'] ?? '-'); ?></td>
                    <td class="px-4 py-2"><?php echo e($reseller['Punya Rekening'] ?? '-'); ?></td>
                    <td class="px-4 py-2"><?php echo e($reseller['Nama Bank'] ?? '-'); ?></td>
                    <td class="px-4 py-2"><?php echo e($reseller['Nomor Rekening'] ?? '-'); ?></td>
                    <td class="px-4 py-2"><?php echo e($reseller['Atas Nama'] ?? '-'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center py-4">Belum ada data reseller.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Downloads\Project Web\sapi-berkah-amanah\backend\resources\views/admin/reseller/reseller.blade.php ENDPATH**/ ?>